import os


def run():
	os.system('python predict.py AAAAAA')
